from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///tasks.db'
db = SQLAlchemy(app)

class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    priority = db.Column(db.String(10), default='Medium')
    due_date = db.Column(db.Date, nullable=True)
    completed = db.Column(db.Boolean, default=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/')
def index():
    q = request.args.get('q', '')
    sort = request.args.get('sort', 'date')
    show = request.args.get('show', 'all')
    tasks = Task.query

    if q:
        tasks = tasks.filter(Task.title.contains(q))

    if show == 'completed':
        tasks = tasks.filter_by(completed=True)
    elif show == 'pending':
        tasks = tasks.filter_by(completed=False)

    if sort == 'priority':
        tasks = tasks.order_by(Task.priority.desc())
    elif sort == 'due':
        tasks = tasks.order_by(Task.due_date.asc())
    else:
        tasks = tasks.order_by(Task.date_created.desc())

    tasks = tasks.all()
    current_date = datetime.now().date()

    return render_template('index.html', tasks=tasks, q=q, sort=sort, show=show, current_date=current_date)

@app.route('/add', methods=['POST'])
def add():
    title = request.form['title']
    priority = request.form['priority']
    due_date_str = request.form['due_date']
    due_date = datetime.strptime(due_date_str, '%Y-%m-%d').date() if due_date_str else None
    new_task = Task(title=title, priority=priority, due_date=due_date)
    db.session.add(new_task)
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/toggle/<int:id>')
def toggle(id):
    task = Task.query.get_or_404(id)
    task.completed = not task.completed
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/delete/<int:id>')
def delete(id):
    task = Task.query.get_or_404(id)
    db.session.delete(task)
    db.session.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
